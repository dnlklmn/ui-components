// logout on account page
// h1
// body text
// title version with logo
